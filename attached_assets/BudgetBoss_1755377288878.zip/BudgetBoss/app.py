import streamlit as st
import pandas as pd

# Page configuration
st.set_page_config(
    page_title="Smart Recommender",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for elegant, modern styling with mobile support
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 3rem 2rem;
        border-radius: 20px;
        color: white;
        text-align: center;
        margin-bottom: 3rem;
        box-shadow: 0 8px 32px rgba(0,0,0,0.12);
    }
    
    .main-header h1 {
        margin: 0;
        font-size: 2.5rem;
        font-weight: 300;
        letter-spacing: -1px;
    }
    
    .main-header p {
        margin: 1rem 0 0 0;
        font-size: 1.1rem;
        opacity: 0.9;
    }
    
    /* Mobile responsive adjustments */
    @media (max-width: 768px) {
        .main-header {
            padding: 2rem 1rem;
            margin-bottom: 2rem;
        }
        
        .main-header h1 {
            font-size: 1.8rem;
        }
        
        .main-header p {
            font-size: 1rem;
        }
    }
    
    .category-stats {
        background: rgba(255,255,255,0.95);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        margin-bottom: 1.5rem;
        text-align: center;
        border: 1px solid rgba(102, 126, 234, 0.1);
    }
    
    .item-card {
        background: #ffffff;
        padding: 2rem;
        border-radius: 20px;
        box-shadow: 0 4px 24px rgba(0,0,0,0.06);
        margin-bottom: 2.5rem;
        border: 1px solid rgba(0,0,0,0.04);
        transition: all 0.3s ease;
    }
    
    .item-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 32px rgba(0,0,0,0.1);
    }
    
    /* Mobile card adjustments */
    @media (max-width: 768px) {
        .item-card {
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-radius: 15px;
        }
        
        .item-card h3 {
            color: #212529 !important;
        }
        
        .item-card p {
            color: #495057 !important;
        }
    }
    
    .recommendation-card {
        background: #f8f9fa;
        padding: 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        border: 1px solid rgba(102, 126, 234, 0.15);
        position: relative;
        transition: all 0.3s ease;
    }
    
    .recommendation-card:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 28px rgba(102, 126, 234, 0.15);
    }
    
    /* Mobile recommendation adjustments */
    @media (max-width: 768px) {
        .recommendation-card {
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            border-radius: 15px;
        }
        
        .recommendation-card h3, .recommendation-card h4 {
            color: #212529 !important;
        }
        
        .recommendation-card p {
            color: #495057 !important;
        }
    }
    
    .rating-section {
        background: rgba(248, 249, 250, 0.6);
        padding: 1.5rem;
        border-radius: 15px;
        margin-top: 1rem;
        border: 1px solid rgba(0,0,0,0.05);
        backdrop-filter: blur(10px);
    }
    
    .star-button {
        background: none;
        border: none;
        font-size: 1.8rem;
        padding: 0.5rem;
        margin: 0 0.3rem;
        cursor: pointer;
        border-radius: 8px;
        transition: all 0.2s ease;
        color: #ddd;
    }
    
    .star-button:hover {
        background: rgba(102, 126, 234, 0.1);
        transform: scale(1.1);
    }
    
    .star-button.active {
        color: #ffc107;
        text-shadow: 0 0 8px rgba(255, 193, 7, 0.3);
    }
    
    .rating-badge {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 0.4rem 1rem;
        border-radius: 25px;
        font-weight: 500;
        font-size: 0.9rem;
        display: inline-block;
        box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
    }
    
    .tag {
        background: rgba(233, 236, 239, 0.8);
        color: #495057;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.85rem;
        margin: 0.3rem 0.4rem 0.3rem 0;
        display: inline-block;
        font-weight: 500;
        backdrop-filter: blur(5px);
    }
    
    .progress-container {
        background: rgba(255,255,255,0.9);
        padding: 1.5rem;
        border-radius: 15px;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 16px rgba(0,0,0,0.06);
        border: 1px solid rgba(102, 126, 234, 0.1);
    }
    
    .recommendation-badge {
        position: absolute;
        top: -8px;
        right: 20px;
        background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-size: 0.8rem;
        font-weight: 600;
        box-shadow: 0 2px 12px rgba(40, 167, 69, 0.3);
    }
    
    .welcome-state {
        text-align: center;
        padding: 3rem 2rem;
        color: #6c757d;
        background: #ffffff;
        border-radius: 20px;
        margin: 2rem 0;
        border: 1px solid #e9ecef;
    }
    
    .welcome-state .icon {
        font-size: 4rem;
        margin-bottom: 1.5rem;
        display: block;
    }
    
    .welcome-state h4 {
        color: #495057;
        margin-bottom: 1rem;
        font-weight: 300;
    }
    
    /* Mobile welcome state */
    @media (max-width: 768px) {
        .welcome-state {
            padding: 2rem 1rem;
            margin: 1rem 0;
        }
        
        .welcome-state .icon {
            font-size: 3rem;
        }
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    try:
        items = pd.read_csv("data/items.csv")
        return items
    except FileNotFoundError:
        st.error("Data file not found. Please ensure 'data/items.csv' exists.")
        return pd.DataFrame()
    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        return pd.DataFrame()

def init_session_state():
    if 'ratings' not in st.session_state:
        st.session_state.ratings = {}
    if 'selected_category' not in st.session_state:
        st.session_state.selected_category = None

def get_live_recommendations(items, user_ratings, selected_category, num_recs=3):
    if len(user_ratings) < 2:
        return []
    
    category_items = items[items['category'] == selected_category]
    unrated_items = category_items[~category_items['name'].isin(user_ratings.keys())]
    
    if len(unrated_items) == 0:
        return []
    
    recommendations = []
    
    for _, item in unrated_items.iterrows():
        score = 0.0
        reasons = []
        
        # Base score from item rating
        base_score = item.get('rating', 3.0) if pd.notna(item.get('rating', 3.0)) else 3.0
        score += base_score * 0.3
        
        # Boost from genre similarity
        item_genre = item.get('genre', '')
        if pd.notna(item_genre):
            for rated_item, rating in user_ratings.items():
                if rating >= 3:
                    rated_data = items[items['name'] == rated_item]
                    if not rated_data.empty:
                        rated_genre = rated_data.iloc[0].get('genre', '')
                        if pd.notna(rated_genre) and rated_genre == item_genre:
                            boost = rating * 0.5
                            score += boost
                            reasons.append(f"Similar to {rated_item}")
                            break
        
        # Boost from year similarity
        item_year = item.get('year', None)
        if pd.notna(item_year):
            for rated_item, rating in user_ratings.items():
                if rating >= 4:
                    rated_data = items[items['name'] == rated_item]
                    if not rated_data.empty:
                        rated_year = rated_data.iloc[0].get('year', None)
                        if pd.notna(rated_year) and abs(item_year - rated_year) <= 10:
                            score += rating * 0.3
                            break
        
        # Create explanation
        if not reasons:
            explanation = f"Highly rated {selected_category.lower()}" if base_score >= 4.0 else f"Popular {selected_category.lower()}"
        else:
            explanation = reasons[0]
        
        recommendations.append((item['name'], score, explanation))
    
    recommendations.sort(key=lambda x: x[1], reverse=True)
    return recommendations[:num_recs]

def render_star_rating(item_name):
    current_rating = st.session_state.ratings.get(item_name, 0)
    
    # Rating buttons with better spacing
    cols = st.columns([1, 1, 1, 1, 1])
    
    for i in range(1, 6):
        with cols[i-1]:
            if st.button(
                f"★ {i}",
                key=f"rate_{item_name}_{i}",
                use_container_width=True,
                type="primary" if i == current_rating else "secondary"
            ):
                st.session_state.ratings[item_name] = i
                st.rerun()
    
    # Show current rating and clear option
    if current_rating > 0:
        col1, col2 = st.columns([2, 1])
        with col1:
            st.caption(f"Rating: {current_rating}/5")
        with col2:
            if st.button("✕", key=f"clear_{item_name}", help="Clear rating"):
                del st.session_state.ratings[item_name]
                st.rerun()
    else:
        st.caption("Not rated")

def main():
    init_session_state()
    items = load_data()
    
    if items.empty:
        st.stop()
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>Smart Recommendation Engine</h1>
        <p>Rate items you know and discover new favorites instantly</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar - simplified
    with st.sidebar:
        st.markdown("### Choose Category")
        
        categories = sorted(items['category'].unique())
        selected_category = st.selectbox(
            "What are you interested in?",
            categories,
            index=0 if st.session_state.selected_category is None else (
                categories.index(st.session_state.selected_category) 
                if st.session_state.selected_category in categories else 0
            ),
            label_visibility="collapsed"
        )
        
        if selected_category != st.session_state.selected_category:
            st.session_state.selected_category = selected_category
            st.session_state.ratings = {}
            st.rerun()
        
        # Simple stats
        category_count = len(items[items['category'] == selected_category])
        rated_count = len([r for r in st.session_state.ratings.values() if r > 0])
        
        st.markdown(f"""
        <div class="category-stats">
            <strong>{selected_category}</strong><br>
            {category_count} items • {rated_count} rated
        </div>
        """, unsafe_allow_html=True)
        
        # Progress
        if rated_count > 0:
            progress = min(rated_count / 5, 1.0)
            st.markdown(f"""
            <div class="progress-container">
                <strong>Progress:</strong> {rated_count}/5+ ratings<br>
                <div style="background: #e9ecef; border-radius: 10px; height: 8px; margin-top: 8px;">
                    <div style="background: #667eea; height: 8px; border-radius: 10px; width: {progress*100}%;"></div>
                </div>
            </div>
            """, unsafe_allow_html=True)
        
        # Quick actions
        if rated_count > 0:
            if st.button("Clear All Ratings", use_container_width=True):
                st.session_state.ratings = {}
                st.rerun()
    
    # Main content - consistent two-column layout
    filtered_items = items[items['category'] == selected_category]
    actual_ratings = {k: v for k, v in st.session_state.ratings.items() if v > 0}
    
    # Get live recommendations
    recommendations = get_live_recommendations(items, actual_ratings, st.session_state.selected_category)
    
    # Always use two-column layout for consistency
    col1, col2 = st.columns([1.5, 1], gap="large")
    
    with col1:
        st.markdown("### Rate Items")
        render_items(filtered_items)
    
    with col2:
        st.markdown("### Recommendations")
        render_recommendations_area(recommendations, items, actual_ratings)

def render_items(filtered_items):
    for _, item in filtered_items.iterrows():
        current_rating = st.session_state.ratings.get(item['name'], 0)
        
        # Item card
        with st.container():
            st.markdown(f"""
            <div class="item-card">
                <h3 style="margin-top: 0; color: #212529;">{item['name']}</h3>
            </div>
            """, unsafe_allow_html=True)
            
            col1, col2 = st.columns([2.5, 1], gap="medium")
            
            with col1:
                # Description
                if 'description' in item.index and pd.notna(item['description']):
                    description = item['description']
                    if len(description) > 120:
                        description = description[:120] + "..."
                    st.write(description)
                
                # Tags
                tags_html = ""
                if 'genre' in item.index and pd.notna(item['genre']):
                    tags_html += f'<span class="tag">{item["genre"]}</span>'
                if 'year' in item.index and pd.notna(item['year']):
                    tags_html += f'<span class="tag">{int(item["year"])}</span>'
                if 'rating' in item.index and pd.notna(item['rating']):
                    tags_html += f'<span class="tag">★ {item["rating"]:.1f}</span>'
                
                if tags_html:
                    st.markdown(tags_html, unsafe_allow_html=True)
            
            with col2:
                st.markdown("**Your Rating:**")
                render_star_rating(item['name'])

def render_recommendations_area(recommendations, items, actual_ratings):
    """Render the recommendations area with elegant states"""
    if len(actual_ratings) == 0:
        st.markdown("""
        <div class="welcome-state">
            <h4>Discover Your Perfect Match</h4>
            <p>Start rating items to unlock personalized recommendations tailored just for you</p>
        </div>
        """, unsafe_allow_html=True)
    
    elif len(actual_ratings) == 1:
        st.markdown("""
        <div class="welcome-state">
            <span class="icon">⭐</span>
            <h4>You're Almost There!</h4>
            <p>Rate one more item to activate our smart recommendation engine</p>
        </div>
        """, unsafe_allow_html=True)
    
    elif recommendations:
        st.markdown('<div style="margin-top: 1rem;"></div>', unsafe_allow_html=True)
        
        for i, (item_name, score, explanation) in enumerate(recommendations, 1):
            item_data = items[items['name'] == item_name].iloc[0]
            
            st.markdown(f"""
            <div class="recommendation-card">
                <div class="recommendation-badge">#{i}</div>
                <h3 style="margin-top: 0; color: #212529; font-weight: 300;">{item_name}</h3>
            </div>
            """, unsafe_allow_html=True)
            
            # Description with better typography
            if 'description' in item_data.index and pd.notna(item_data['description']):
                description = item_data['description']
                if len(description) > 120:
                    description = description[:120] + "..."
                st.markdown(f'<p style="color: #6c757d; line-height: 1.6; margin-bottom: 1rem;">{description}</p>', unsafe_allow_html=True)
            
            # Why recommended
            st.markdown(f'<p style="color: #495057; font-style: italic; margin-bottom: 1rem;">💡 {explanation}</p>', unsafe_allow_html=True)
            
            # Tags with better styling
            tags_html = ""
            if 'genre' in item_data.index and pd.notna(item_data['genre']):
                tags_html += f'<span class="tag">{item_data["genre"]}</span>'
            if 'rating' in item_data.index and pd.notna(item_data['rating']):
                tags_html += f'<span class="tag">★ {item_data["rating"]:.1f}</span>'
            
            if tags_html:
                st.markdown(f'<div style="margin: 1rem 0;">{tags_html}</div>', unsafe_allow_html=True)
            
            # Match score
            st.markdown(f'<div style="text-align: right; margin-top: 1rem;"><span class="rating-badge">Match Score: {score:.1f}/5</span></div>', unsafe_allow_html=True)
    
    else:
        st.markdown("""
        <div class="welcome-state">
            <span class="icon">🔄</span>
            <h4>Building Your Profile...</h4>
            <p>Rate a few more items to improve recommendation accuracy</p>
        </div>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()