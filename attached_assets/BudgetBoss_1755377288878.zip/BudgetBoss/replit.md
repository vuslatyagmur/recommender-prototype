# Smart Preference Elicitation Recommender System

## Overview

This is a Streamlit-based recommendation system that helps users discover personalized item recommendations through an interactive preference elicitation interface. The system allows users to select categories of interest, rate items within those categories, and receive intelligent recommendations based on their preferences. The application uses both content-based filtering and user preference analysis to generate personalized suggestions.

## User Preferences

Preferred communication style: Simple, everyday language.
Design preferences: Creative, user-friendly, and informative interface design with engaging visual elements.

## System Architecture

### Frontend Architecture
The application uses Streamlit as the primary web framework, providing an interactive user interface with the following key components:
- **Category Selection**: Users can filter items by category through a dropdown selector
- **Rating Interface**: Interactive sliders allow users to rate items on a 1-5 scale
- **Recommendation Display**: Results are presented in a clean, user-friendly format
- **Session Management**: User ratings and recommendation history are preserved using Streamlit's session state

### Backend Architecture
The system follows a modular design pattern with clear separation of concerns:
- **Main Application Logic** (`app.py`): Handles UI components, user interactions, and data flow orchestration
- **Recommendation Engine** (`utils/recommender.py`): Implements the core recommendation algorithms using content-based filtering
- **Data Layer**: CSV-based data storage for items with support for various item attributes (category, genre, etc.)

### Data Storage Solutions
The application uses a simple file-based storage approach:
- **Items Data**: Stored in CSV format (`data/items.csv`) containing item metadata including names, categories, genres, and other attributes
- **Session Data**: User preferences and ratings are maintained in-memory using Streamlit's session state
- **Caching Strategy**: Data loading is optimized using Streamlit's `@st.cache_data` decorator

### Recommendation Algorithm
The system implements a hybrid recommendation approach:
- **Content-Based Filtering**: Calculates similarity between items based on shared attributes like genre and category
- **Preference Analysis**: Uses user ratings to identify preferences and generate personalized recommendations
- **Similarity Caching**: Implements caching mechanisms to optimize performance for repeated calculations

## External Dependencies

### Core Framework Dependencies
- **Streamlit**: Primary web application framework for creating the interactive user interface
- **Pandas**: Data manipulation and analysis library for handling item datasets and user preferences
- **NumPy**: Numerical computing library supporting the recommendation algorithms

### Data Dependencies
- **Items Dataset**: CSV file containing item information with required columns (name, category) and optional attributes (genre, etc.)
- The system is designed to be flexible with data schema, supporting additional item attributes for enhanced recommendation accuracy

### Development Dependencies
- **Python 3.x**: Runtime environment
- Standard library modules for data processing and utility functions